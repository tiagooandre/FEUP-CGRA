class MyCubePlane extends CGFobject {
    constructor(scene) {
        super(scene);

        this.square = new MyDiamond()
    }
}